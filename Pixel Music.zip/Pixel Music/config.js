const CONFIG = {
    // Multiple API keys from DIFFERENT projects (30,000 quota total)
    YOUTUBE_API_KEYS: [
        'AIzaSyDY-ufmQhtcervNNLQRL1OkYJt9CfAbz6E',  // Project 1 - PixelNote
        'AIzaSyAeBB7Da04VZ6gyF4g3gHyaf0uu7-yyttA',  // Project 2 - New
        'AIzaSyDZE9p4o_LkZ1ClL094qaxK5WjMi1IYHMU'   // Project 3 - New
    ],
    CURRENT_KEY_INDEX: 0,  // Tracks which key to use
    GOOGLE_CLIENT_ID: '469366716838-3140k3fu6lqrrj7uvfv11u8a29jdsrvb.apps.googleusercontent.com',
    MAX_SEARCH_RESULTS: 20,
    DEFAULT_VOLUME: 50,
    
    // Helper function to get current API key
    getCurrentApiKey() {
        return this.YOUTUBE_API_KEYS[this.CURRENT_KEY_INDEX];
    },
    
    // Helper function to rotate to next key
    rotateApiKey() {
        this.CURRENT_KEY_INDEX = (this.CURRENT_KEY_INDEX + 1) % this.YOUTUBE_API_KEYS.length;
        console.log(`Rotated to API Key ${this.CURRENT_KEY_INDEX + 1}`);
        return this.getCurrentApiKey();
    }
};
