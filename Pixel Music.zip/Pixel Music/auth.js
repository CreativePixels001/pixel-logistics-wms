// Google Sign-In Handler
function handleCredentialResponse(response) {
    // Decode JWT token
    const responsePayload = parseJwt(response.credential);
    
    console.log("ID: " + responsePayload.sub);
    console.log('Full Name: ' + responsePayload.name);
    console.log('Email: ' + responsePayload.email);
    console.log("Image URL: " + responsePayload.picture);
    
    // Save user data to localStorage
    const userData = {
        name: responsePayload.name,
        email: responsePayload.email,
        picture: responsePayload.picture,
        loginType: 'google'
    };
    localStorage.setItem('pixelMusicUser', JSON.stringify(userData));
    
    // Track login event
    if (typeof trackLogin === 'function') {
        trackLogin('google');
    }
    
    // Show user info
    document.getElementById('userName').innerHTML = `
        <img src="${responsePayload.picture}" alt="${responsePayload.name}" 
             style="width: 32px; height: 32px; border-radius: 50%; vertical-align: middle; margin-right: 8px;">
        ${responsePayload.name}
    `;
    
    showApp();
}

// Parse JWT token
function parseJwt(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    
    return JSON.parse(jsonPayload);
}

// Skip login for development
function skipLogin() {
    // Save guest user data to localStorage
    const userData = {
        name: 'Guest User',
        loginType: 'guest'
    };
    localStorage.setItem('pixelMusicUser', JSON.stringify(userData));
    
    // Track guest login
    if (typeof trackLogin === 'function') {
        trackLogin('guest');
    }
    
    document.getElementById('userName').innerHTML = `
        <i class="bi bi-person-circle" style="font-size: 1.5rem; vertical-align: middle; margin-right: 8px;"></i>
        Guest User
    `;
    showApp();
}

// Show main app
function showApp() {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('appScreen').style.display = 'block';
}

// Logout
function logout() {
    // Clear localStorage
    localStorage.removeItem('pixelMusicUser');
    
    if (google && google.accounts && google.accounts.id) {
        google.accounts.id.disableAutoSelect();
    }
    
    document.getElementById('loginScreen').style.display = 'flex';
    document.getElementById('appScreen').style.display = 'none';
    document.getElementById('userName').textContent = '';
    
    // Reset player
    resetApp();
}

// Reset app state
function resetApp() {
    // Stop playback
    if (player && player.stopVideo) {
        player.stopVideo();
    }
    if (audioPlayer) {
        audioPlayer.pause();
        audioPlayer.src = '';
    }
    
    // Clear UI
    resetPlayer();
    
    // Clear search results
    youtubeSearchResults = [];
    document.getElementById('songList').innerHTML = '';
    document.getElementById('searchInput').value = '';
}

// Check for existing session on page load
function checkExistingSession() {
    const storedUser = localStorage.getItem('pixelMusicUser');
    
    if (storedUser) {
        try {
            const userData = JSON.parse(storedUser);
            
            // Restore user UI based on login type
            if (userData.loginType === 'google' && userData.picture) {
                document.getElementById('userName').innerHTML = `
                    <img src="${userData.picture}" alt="${userData.name}" 
                         style="width: 32px; height: 32px; border-radius: 50%; vertical-align: middle; margin-right: 8px;">
                    ${userData.name}
                `;
            } else {
                document.getElementById('userName').innerHTML = `
                    <i class="bi bi-person-circle" style="font-size: 1.5rem; vertical-align: middle; margin-right: 8px;"></i>
                    ${userData.name}
                `;
            }
            
            // Show app directly
            showApp();
            return true;
        } catch (e) {
            console.error('Error restoring session:', e);
            localStorage.removeItem('pixelMusicUser');
        }
    }
    
    return false;
}

// Initialize session check on page load
window.addEventListener('DOMContentLoaded', function() {
    const isLoggedIn = checkExistingSession();
    
    // Cancel Google One Tap if already logged in
    if (isLoggedIn && google && google.accounts && google.accounts.id) {
        google.accounts.id.cancel();
    }
});
