# Pixel Play - Retro Vinyl Player 🎵

A beautiful retro-themed music player with vinyl disc aesthetics, featuring YouTube streaming, local file playback, real-time lyrics display, and mobile background playback support.

## Features ✨

### Music Playback
- **YouTube Integration** - Search and stream music from YouTube
- **Local Files** - Upload and play audio files from your device (MP3, WAV, OGG, M4A)
- **Drag & Drop** - Easy file upload with drag and drop support
- **Background Playback** 📱 - Continue playing music when app is minimized on mobile
- **Lock Screen Controls** - Control playback from your phone's lock screen/notification center

### User Interface
- **Retro Vinyl Design** - Animated vinyl disc with realistic grooves and tonearm
- **Greyscale Theme** - Classic black and white aesthetic with vintage effects
- **Film Grain & Scan Lines** - Authentic retro visual effects
- **Fullscreen Mode** - Immersive playback experience (Press F key)

### Lyrics Display 🎤
- **Real-time Lyrics** - Automatically fetches and displays song lyrics
- **Free API** - Uses Lyrics.ovh (no API key required)
- **Microphone Icon** - Toggle lyrics panel with a single click
- **Clean Layout** - Retro-styled scrollable lyrics panel

### Playback Controls
- **Play/Pause, Next, Previous** - Full playback control
- **Volume Control** - Adjustable volume slider
- **Progress Tracking** - Seekable progress bar
- **Keyboard Shortcuts** - Space (play/pause), Arrow keys (next/prev), F (fullscreen)
- **Media Session API** - Native media controls on mobile devices

### Authentication
- **Google Sign-In** - Optional login with Google account
- **Guest Mode** - Continue without login for quick access
- **Persistent Sessions** - Stay logged in across page refreshes

## Keyboard Shortcuts ⌨️

| Key | Action |
|-----|--------|
| `⌘K` / `Ctrl+K` | Focus Search |
| `Space` | Play/Pause |
| `←` | Previous Song |
| `→` | Next Song |
| `F` | Toggle Fullscreen |
| `Esc` | Clear Search |

## Technologies Used 🛠️

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Framework**: Bootstrap 5.3.0
- **APIs**:
  - YouTube Data API v3 (search)
  - YouTube IFrame Player API (playback)
  - Lyrics.ovh API (lyrics fetching)
  - Google OAuth 2.0 (authentication)
  - Media Session API (background playback controls)
- **PWA Features**:
  - Service Worker (offline support & caching)
  - Background audio handling
  - Mobile lock screen integration
- **Fonts**: Google Fonts (Playfair Display, Roboto, Roboto Mono)

## Setup Instructions 📋

1. **Upload Files** to your web server:
   - `index.html`
   - `style.css`
   - `app.js`
   - `auth.js`
   - `config.js`
   - `service-worker.js` (NEW - for background playback)

2. **Configure API Keys** in `config.js`:
   ```javascript
   const CONFIG = {
       YOUTUBE_API_KEY: 'your-youtube-api-key',
       GOOGLE_CLIENT_ID: 'your-google-client-id',
       MAX_SEARCH_RESULTS: 20,
       DEFAULT_VOLUME: 50
   };
   ```

3. **Update Google Cloud Console**:
   - Add your domain to YouTube API restrictions
   - Add your domain to OAuth authorized origins

## How Lyrics Work 🎤

The lyrics feature uses the free **Lyrics.ovh API**:

1. When you play a YouTube song, the app automatically fetches lyrics
2. The song title and artist are cleaned (removes "Official Video", etc.)
3. The API searches for matching lyrics
4. Lyrics are displayed in a retro-styled panel on the right side
5. Click the microphone icon to toggle the lyrics panel

**Note**: Lyrics availability depends on the API's database. Not all songs have lyrics available.

## Mobile Background Playback 📱

The app now supports background playback on mobile devices:

### How it Works:
1. **Media Session API** - Integrates with your phone's native media controls
2. **Lock Screen Controls** - Play, pause, skip tracks from lock screen or notification center
3. **Service Worker** - Keeps audio playing when app is minimized
4. **Metadata Display** - Shows song title, artist, and artwork on lock screen

### Best Experience:
- **Local Files**: Full background playback support on all mobile browsers
- **YouTube**: Limited by browser policies, works best in Chrome for Android

### Controls Available:
- ▶️ Play/Pause
- ⏭️ Next Track
- ⏮️ Previous Track
- ⏩ Seek Forward (10 seconds)
- ⏪ Seek Backward (10 seconds)

## Browser Support 🌐

- Chrome/Edge (Recommended)
- Firefox
- Safari
- Opera
- Mobile browsers (Chrome, Safari, Firefox) with Media Session support

## Credits 👨‍💻

Developed by Creative Pixels  
© 2025 Pixel Play

## License 📄

MIT License - Feel free to use and modify!
