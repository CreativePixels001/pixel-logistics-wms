// Global Variables
let player;
let currentPlatform = 'youtube';
let currentSongIndex = -1;
let youtubeSearchResults = [];
let localFiles = [];
let isPlaying = false;
let audioPlayer;
let isMuted = false;
let previousVolume = 50;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    registerServiceWorker();
    setSearchPlaceholder();
});

function initializeApp() {
    console.log('Initializing app...');
    
    audioPlayer = document.getElementById('audioPlayer');
    
    // Initialize Media Session API for background playback controls
    initializeMediaSession();
    
    // Search button event
    const searchBtn = document.getElementById('searchBtn');
    if (searchBtn) {
        searchBtn.addEventListener('click', performSearch);
        console.log('Search button listener attached');
    } else {
        console.error('searchBtn not found!');
    }
    
    // Enter key in search input
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                console.log('Enter key pressed in search');
                performSearch();
            }
        });
        console.log('Search input listener attached');
    } else {
        console.error('searchInput not found!');
    }
    
    // Mobile search button event
    const mobileSearchBtn = document.getElementById('mobileSearchBtn');
    if (mobileSearchBtn) {
        mobileSearchBtn.addEventListener('click', performMobileSearch);
    }
    
    // Enter key in mobile search input
    const mobileSearchInput = document.getElementById('mobileSearchInput');
    if (mobileSearchInput) {
        mobileSearchInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                performMobileSearch();
            }
        });
    }
    
    // Progress slider
    const progressSlider = document.getElementById('progressSlider');
    progressSlider.addEventListener('input', function() {
        if (currentPlatform === 'youtube' && player && player.getDuration) {
            const seekTime = (player.getDuration() * progressSlider.value) / 100;
            player.seekTo(seekTime, true);
        } else if (currentPlatform === 'local' && audioPlayer.duration) {
            const seekTime = (audioPlayer.duration * progressSlider.value) / 100;
            audioPlayer.currentTime = seekTime;
        }
    });
    
    // Volume slider
    const volumeSlider = document.getElementById('volumeSlider');
    volumeSlider.addEventListener('input', function() {
        if (player && player.setVolume) {
            player.setVolume(volumeSlider.value);
        }
        if (audioPlayer) {
            audioPlayer.volume = volumeSlider.value / 100;
        }
    });
    
    // Audio player events
    audioPlayer.addEventListener('timeupdate', updateLocalProgress);
    audioPlayer.addEventListener('ended', function() {
        // Check if autoplay is enabled for local files too
        const autoplayEnabled = localStorage.getItem('autoplayEnabled') !== 'false';
        if (autoplayEnabled) {
            playNext();
        } else {
            stopVinylAnimation();
            updatePlayButton();
        }
    });
    
    // Keyboard shortcuts
    document.addEventListener('keydown', function(e) {
        // Cmd+K or Ctrl+K to focus search
        if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
            e.preventDefault();
            console.log('Cmd+K detected, focusing search...');
            if (typeof trackKeyboardShortcut === 'function') {
                trackKeyboardShortcut('cmd_k');
            }
            focusSearch();
            return;
        }
        
        // Skip if typing in input field (except for Cmd+K)
        if (e.target.tagName === 'INPUT') return;
        
        switch(e.code) {
            case 'Space':
                e.preventDefault();
                togglePlayPause();
                break;
            case 'ArrowLeft':
                e.preventDefault();
                playPrevious();
                break;
            case 'ArrowRight':
                e.preventDefault();
                playNext();
                break;
            case 'KeyF':
                e.preventDefault();
                toggleFullscreen();
                break;
            case 'Escape':
                // Clear search on ESC
                if (document.activeElement.id === 'searchInput' || 
                    document.activeElement.id === 'mobileSearchInput') {
                    e.preventDefault();
                    clearSearch();
                }
                break;
        }
    });
}

// Focus search box function
function focusSearch() {
    const searchInput = document.getElementById('searchInput');
    const mobileSearchModal = document.getElementById('mobileSearchModal');
    
    // Check if mobile view
    if (window.innerWidth <= 768) {
        // Open mobile search modal
        toggleMobileSearch();
        setTimeout(() => {
            document.getElementById('mobileSearchInput').focus();
        }, 100);
    } else {
        // Focus desktop search
        searchInput.focus();
        searchInput.select();
    }
}

// Clear search function
function clearSearch() {
    const searchInput = document.getElementById('searchInput');
    const mobileSearchInput = document.getElementById('mobileSearchInput');
    
    if (searchInput) {
        searchInput.value = '';
        searchInput.blur();
    }
    if (mobileSearchInput) {
        mobileSearchInput.value = '';
    }
}

// Set search placeholder with correct keyboard shortcut
function setSearchPlaceholder() {
    const isMac = navigator.platform.toUpperCase().indexOf('MAC') >= 0;
    const shortcut = isMac ? '⌘K' : 'Ctrl+K';
    
    const searchInput = document.getElementById('searchInput');
    const mobileSearchInput = document.getElementById('mobileSearchInput');
    const shortcutBadge = document.getElementById('searchShortcutBadge');
    
    if (searchInput) {
        searchInput.placeholder = 'Search for records...';
    }
    if (mobileSearchInput) {
        mobileSearchInput.placeholder = 'Search for records...';
    }
    if (shortcutBadge) {
        shortcutBadge.textContent = shortcut;
    }
}

// YouTube IFrame API Ready
function onYouTubeIframeAPIReady() {
    player = new YT.Player('youtubePlayer', {
        height: '0',
        width: '0',
        playerVars: {
            'playsinline': 1,
            'controls': 0,
            'rel': 0,
            'showinfo': 0,
            'modestbranding': 1
        },
        events: {
            'onReady': onPlayerReady,
            'onStateChange': onPlayerStateChange
        }
    });
}

function onPlayerReady(event) {
    const volumeSlider = document.getElementById('volumeSlider');
    player.setVolume(volumeSlider.value);
    setInterval(updateProgress, 1000);
}

function onPlayerStateChange(event) {
    if (event.data === YT.PlayerState.ENDED) {
        // Check if autoplay is enabled
        const autoplayEnabled = localStorage.getItem('autoplayEnabled') !== 'false';
        if (autoplayEnabled) {
            playNext();
        } else {
            stopVinylAnimation();
            updatePlayButton();
        }
    } else if (event.data === YT.PlayerState.PLAYING) {
        isPlaying = true;
        startVinylAnimation();
        updatePlayButton();
    } else {
        isPlaying = false;
        stopVinylAnimation();
        updatePlayButton();
    }
}

// Autoplay Toggle
function toggleAutoplay() {
    const currentState = localStorage.getItem('autoplayEnabled') !== 'false';
    const newState = !currentState;
    localStorage.setItem('autoplayEnabled', newState);
    updateAutoplayButton();
    
    // Show toast notification
    showToast(newState ? '🔁 Autoplay enabled' : '⏸️ Autoplay disabled');
}

function updateAutoplayButton() {
    const autoplayBtn = document.getElementById('autoplayBtn');
    const autoplayEnabled = localStorage.getItem('autoplayEnabled') !== 'false';
    
    if (autoplayBtn) {
        if (autoplayEnabled) {
            autoplayBtn.classList.add('active');
            autoplayBtn.title = 'Autoplay: ON (click to disable)';
        } else {
            autoplayBtn.classList.remove('active');
            autoplayBtn.title = 'Autoplay: OFF (click to enable)';
        }
    }
}

// Initialize autoplay button state on load
window.addEventListener('DOMContentLoaded', function() {
    // Set default autoplay to ON if not set
    if (localStorage.getItem('autoplayEnabled') === null) {
        localStorage.setItem('autoplayEnabled', 'true');
    }
    updateAutoplayButton();
});

// Search YouTube
async function performSearch() {
    console.log('performSearch called');
    const query = document.getElementById('searchInput').value.trim();
    console.log('Search query:', query);
    if (!query) {
        console.log('Empty query, returning');
        return;
    }
    
    // Track search event
    if (typeof trackSearch === 'function') {
        trackSearch(query);
    }
    
    // Switch to YouTube tab to show search results (with safety check)
    if (typeof switchPlatform === 'function') {
        console.log('Switching to youtube platform');
        switchPlatform('youtube');
    }
    
    const songList = document.getElementById('songList');
    songList.innerHTML = '<div class="loading"><i class="bi bi-hourglass-split"></i><p>Searching YouTube for: ' + query + '</p></div>';
    
    try {
        const results = await searchYouTube(query);
        displayYouTubeResults(results);
    } catch (error) {
        console.error('Search error:', error);
        songList.innerHTML = '<div class="error-message"><i class="bi bi-exclamation-triangle"></i><p>Failed to search. ' + error.message + '</p></div>';
    }
}

async function searchYouTube(query, retryCount = 0) {
    // Check cache first (1 hour cache)
    const cacheKey = `search_cache_${query.toLowerCase().trim()}`;
    const cached = localStorage.getItem(cacheKey);
    
    if (cached) {
        const { data, timestamp } = JSON.parse(cached);
        const oneHour = 60 * 60 * 1000; // 1 hour in milliseconds
        
        // Check if cache is still valid
        if (Date.now() - timestamp < oneHour) {
            console.log('Using cached results for:', query);
            return data;
        } else {
            // Clear expired cache
            localStorage.removeItem(cacheKey);
        }
    }
    
    // Check if CONFIG is loaded
    if (typeof CONFIG === 'undefined') {
        console.error('CONFIG is not defined! Make sure config.js is loaded.');
        throw new Error('Configuration not loaded. Please refresh the page.');
    }
    
    const API_KEY = CONFIG.getCurrentApiKey();
    const MAX_RESULTS = CONFIG.MAX_SEARCH_RESULTS;
    
    if (!API_KEY) {
        console.error('YouTube API key is missing!');
        throw new Error('YouTube API key not configured.');
    }
    
    const url = `https://www.googleapis.com/youtube/v3/search?part=snippet&q=${encodeURIComponent(query)}&type=video&videoCategoryId=10&maxResults=${MAX_RESULTS}&key=${API_KEY}`;
    
    console.log('Searching YouTube for:', query, `(Using API Key ${CONFIG.CURRENT_KEY_INDEX + 1})`);
    console.log('API URL:', url.replace(API_KEY, 'API_KEY_HIDDEN'));
    
    const response = await fetch(url);
    
    if (!response.ok) {
        const errorData = await response.json();
        console.error('YouTube API Error:', errorData);
        
        // Check for quota exceeded
        if (errorData.error?.errors?.[0]?.reason === 'quotaExceeded') {
            // Try next API key if available
            if (retryCount < CONFIG.YOUTUBE_API_KEYS.length - 1) {
                console.log(`Key ${CONFIG.CURRENT_KEY_INDEX + 1} quota exceeded. Trying next key...`);
                CONFIG.rotateApiKey();
                return searchYouTube(query, retryCount + 1);
            }
            
            // All keys exhausted
            throw new Error('🎵 All search limits reached! Resets at 12:30 PM IST daily. Meanwhile, browse your ♥️ Records Library!');
        }
        
        throw new Error(errorData.error?.message || 'API Error: ' + response.status + ' - ' + response.statusText);
    }
    
    const data = await response.json();
    console.log('YouTube search results:', data);
    
    const results = data.items || [];
    
    // Cache the results (1 hour)
    if (results.length > 0) {
        localStorage.setItem(cacheKey, JSON.stringify({
            data: results,
            timestamp: Date.now()
        }));
        console.log('Cached search results for:', query);
    }
    
    return results;
}

function displayYouTubeResults(results) {
    youtubeSearchResults = results;
    const songList = document.getElementById('songList');
    
    if (results.length === 0) {
        songList.innerHTML = '<div class="error-message"><p>No results found</p></div>';
        return;
    }
    
    songList.innerHTML = '';
    
    results.forEach((item, index) => {
        const songItem = document.createElement('div');
        songItem.className = 'song-item';
        songItem.onclick = () => playYouTubeSong(index);
        
        const thumbnail = item.snippet.thumbnails.default.url;
        const title = item.snippet.title;
        const channel = item.snippet.channelTitle;
        const videoId = item.id.videoId;
        
        songItem.innerHTML = `
            <img src="${thumbnail}" alt="${title}">
            <div class="song-item-info">
                <div class="song-item-title">${title}</div>
                <div class="song-item-artist">${channel}</div>
            </div>
            <button class="song-heart-btn" onclick="event.stopPropagation(); toggleLibraryHeart('youtube', '${videoId}', '${title.replace(/'/g, "\\'")}', '${channel.replace(/'/g, "\\'")}', '${thumbnail}', this);" title="Add to Records Library">
                <i class="bi bi-heart"></i>
            </button>
        `;
        
        songList.appendChild(songItem);
    });
    
    syncHeartStates();
}

function playYouTubeSong(index) {
    if (!youtubeSearchResults[index]) return;
    
    currentPlatform = 'youtube';
    currentSongIndex = index;
    
    const videoId = youtubeSearchResults[index].id.videoId;
    const title = youtubeSearchResults[index].snippet.title;
    const channel = youtubeSearchResults[index].snippet.channelTitle;
    const thumbnail = youtubeSearchResults[index].snippet.thumbnails.high?.url || youtubeSearchResults[index].snippet.thumbnails.default.url;
    
    // Track song play
    if (typeof trackSongPlay === 'function') {
        trackSongPlay(title, channel, 'youtube');
    }
    
    // Stop local audio if playing
    audioPlayer.pause();
    
    // Load and play video
    if (player && player.loadVideoById) {
        player.loadVideoById(videoId);
        player.playVideo();
    }
    
    // Update UI
    updateSongInfo(title, channel, thumbnail);
    updateActiveItem('songList', index);
    
    // Update Media Session metadata for background playback
    updateMediaSessionMetadata(title, channel, thumbnail);
    
    // Trigger disc slide-up animation
    triggerDiscAnimation();
    
    // Fetch and display lyrics
    fetchLyrics(title, channel);
}

// Handle Local Files
function handleFiles(files) {
    Array.from(files).forEach(file => {
        if (file.type.startsWith('audio/')) {
            localFiles.push({
                file: file,
                name: file.name,
                url: URL.createObjectURL(file)
            });
        }
    });
    
    displayLocalFiles();
}

function displayLocalFiles() {
    const localSongList = document.getElementById('localSongList');
    
    if (localFiles.length === 0) {
        localSongList.innerHTML = '';
        return;
    }
    
    localSongList.innerHTML = '';
    
    localFiles.forEach((item, index) => {
        const songItem = document.createElement('div');
        songItem.className = 'song-item';
        
        const fileName = item.name.replace(/\.[^/.]+$/, "");
        
        songItem.innerHTML = `
            <i class="bi bi-file-music" style="font-size: 2rem; color: var(--text-dim);"></i>
            <div class="song-item-info" onclick="event.stopPropagation(); playLocalFile(${index});" style="cursor: pointer;">
                <div class="song-item-title">${fileName}</div>
                <div class="song-item-artist">Local File</div>
            </div>
            <button class="song-heart-btn" onclick="event.stopPropagation(); toggleLibraryHeart('local', '${item.url}', '${fileName.replace(/'/g, "\\'")}', 'Local File', '', this);" title="Add to Records Library">
                <i class="bi bi-heart"></i>
            </button>
            <button class="song-item-remove" onclick="event.stopPropagation(); removeLocalFile(${index});">
                <i class="bi bi-trash"></i>
            </button>
        `;
        
        localSongList.appendChild(songItem);
    });
    
    syncHeartStates();
}

function playLocalFile(index) {
    if (!localFiles[index]) return;
    
    currentPlatform = 'local';
    currentSongIndex = index;
    
    const file = localFiles[index];
    const fileName = file.name.replace(/\.[^/.]+$/, "");
    
    // Stop YouTube if playing
    if (player && player.pauseVideo) {
        player.pauseVideo();
    }
    
    // Play local file
    audioPlayer.src = file.url;
    audioPlayer.play();
    
    // Update UI
    updateSongInfo(fileName, 'Local File', null);
    updateActiveItem('localSongList', index);
    
    // Update Media Session metadata for background playback
    updateMediaSessionMetadata(fileName, 'Local File', null);
    
    // Trigger disc slide-up animation
    triggerDiscAnimation();
    
    isPlaying = true;
    startVinylAnimation();
    updatePlayButton();
    
    // Clear lyrics for local files
    clearLyrics();
}

function removeLocalFile(index) {
    URL.revokeObjectURL(localFiles[index].url);
    localFiles.splice(index, 1);
    displayLocalFiles();
    
    if (currentPlatform === 'local' && currentSongIndex === index) {
        audioPlayer.pause();
        audioPlayer.src = '';
        resetPlayer();
    }
}

// Playback Controls
function togglePlayPause() {
    if (currentPlatform === 'youtube' && player && player.getPlayerState) {
        if (player.getPlayerState() === YT.PlayerState.PLAYING) {
            player.pauseVideo();
        } else {
            player.playVideo();
        }
    } else if (currentPlatform === 'local' && audioPlayer.src) {
        if (audioPlayer.paused) {
            audioPlayer.play();
            isPlaying = true;
            startVinylAnimation();
        } else {
            audioPlayer.pause();
            isPlaying = false;
            stopVinylAnimation();
        }
        updatePlayButton();
        
        // Update Media Session playback state
        if ('mediaSession' in navigator) {
            navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
        }
    }
}

function playNext() {
    if (currentPlatform === 'youtube' && youtubeSearchResults.length > 0) {
        const nextIndex = (currentSongIndex + 1) % youtubeSearchResults.length;
        playYouTubeSong(nextIndex);
    } else if (currentPlatform === 'local' && localFiles.length > 0) {
        const nextIndex = (currentSongIndex + 1) % localFiles.length;
        playLocalFile(nextIndex);
    }
}

function playPrevious() {
    if (currentPlatform === 'youtube' && youtubeSearchResults.length > 0) {
        const prevIndex = currentSongIndex - 1 < 0 ? youtubeSearchResults.length - 1 : currentSongIndex - 1;
        playYouTubeSong(prevIndex);
    } else if (currentPlatform === 'local' && localFiles.length > 0) {
        const prevIndex = currentSongIndex - 1 < 0 ? localFiles.length - 1 : currentSongIndex - 1;
        playLocalFile(prevIndex);
    }
}

// Platform Switching
function switchPlatform(platform) {
    currentPlatform = platform;
    
    // Track platform switch
    if (typeof trackPlatformSwitch === 'function') {
        trackPlatformSwitch(platform);
    }
    
    // Update tabs
    document.querySelectorAll('.platform-tabs .nav-link').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelector(`[data-platform="${platform}"]`).classList.add('active');
    
    // Update content
    document.getElementById('youtubeContent').style.display = platform === 'youtube' ? 'block' : 'none';
    document.getElementById('libraryContent').style.display = platform === 'library' ? 'block' : 'none';
    
    // Load library when switching to library tab
    if (platform === 'library') {
        displayLibrarySongs();
    }
    
    // Stop playback when switching
    if (platform === 'youtube' && audioPlayer) {
        audioPlayer.pause();
    } else if (platform === 'library' && player && player.pauseVideo) {
        player.pauseVideo();
    }
}

// UI Updates
function updateSongInfo(title, artist, thumbnail) {
    document.getElementById('currentSongTitle').textContent = title;
    document.getElementById('currentSongArtist').textContent = artist;
    
    const albumArt = document.getElementById('albumArt');
    if (thumbnail) {
        albumArt.innerHTML = `<img src="${thumbnail}" alt="${title}">`;
    } else {
        albumArt.innerHTML = '<i class="bi bi-music-note-beamed"></i>';
    }
}

function updateActiveItem(listId, activeIndex) {
    const list = document.getElementById(listId);
    const items = list.querySelectorAll('.song-item');
    
    items.forEach((item, index) => {
        if (index === activeIndex) {
            item.classList.add('active');
        } else {
            item.classList.remove('active');
        }
    });
}

function updatePlayButton() {
    const playBtn = document.getElementById('playPauseBtn');
    if (isPlaying) {
        playBtn.innerHTML = '<i class="bi bi-pause-fill"></i>';
    } else {
        playBtn.innerHTML = '<i class="bi bi-play-fill"></i>';
    }
}

function resetPlayer() {
    document.getElementById('currentSongTitle').textContent = 'No song playing';
    document.getElementById('currentSongArtist').textContent = 'Select a song to play';
    document.getElementById('albumArt').innerHTML = '<i class="bi bi-music-note-beamed"></i>';
    document.getElementById('currentTime').textContent = '0:00';
    document.getElementById('totalTime').textContent = '0:00';
    document.getElementById('progressBar').style.width = '0%';
    document.getElementById('progressSlider').value = 0;
    
    stopVinylAnimation();
    updatePlayButton();
    clearLyrics();
}

// Progress Updates
function updateProgress() {
    if (player && player.getCurrentTime && player.getDuration) {
        const currentTime = player.getCurrentTime();
        const duration = player.getDuration();
        
        if (duration > 0) {
            const progress = (currentTime / duration) * 100;
            document.getElementById('progressBar').style.width = progress + '%';
            document.getElementById('progressSlider').value = progress;
            
            document.getElementById('currentTime').textContent = formatTime(currentTime);
            document.getElementById('totalTime').textContent = formatTime(duration);
        }
    }
}

function updateLocalProgress() {
    if (audioPlayer.duration) {
        const currentTime = audioPlayer.currentTime;
        const duration = audioPlayer.duration;
        
        const progress = (currentTime / duration) * 100;
        document.getElementById('progressBar').style.width = progress + '%';
        document.getElementById('progressSlider').value = progress;
        
        document.getElementById('currentTime').textContent = formatTime(currentTime);
        document.getElementById('totalTime').textContent = formatTime(duration);
    }
}

function formatTime(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return mins + ':' + (secs < 10 ? '0' : '') + secs;
}

// Vinyl Animation
function startVinylAnimation() {
    const vinylDisc = document.getElementById('vinylDisc');
    const tonearm = document.getElementById('tonearm');
    
    // Add spinning class after slide-up animation completes (1200ms)
    setTimeout(() => {
        vinylDisc.classList.add('spinning');
        tonearm.classList.add('playing');
    }, 1200);
}

function stopVinylAnimation() {
    document.getElementById('vinylDisc').classList.remove('spinning');
    document.getElementById('tonearm').classList.remove('playing');
}

// Fullscreen Mode
function toggleFullscreen() {
    const appScreen = document.getElementById('appScreen');
    
    if (!document.fullscreenElement) {
        appScreen.classList.add('fullscreen-mode');
        if (appScreen.requestFullscreen) {
            appScreen.requestFullscreen();
        } else if (appScreen.webkitRequestFullscreen) {
            appScreen.webkitRequestFullscreen();
        } else if (appScreen.mozRequestFullScreen) {
            appScreen.mozRequestFullScreen();
        }
    } else {
        appScreen.classList.remove('fullscreen-mode');
        if (document.exitFullscreen) {
            document.exitFullscreen();
        } else if (document.webkitExitFullscreen) {
            document.webkitExitFullscreen();
        } else if (document.mozCancelFullScreen) {
            document.mozCancelFullScreen();
        }
    }
}

document.addEventListener('fullscreenchange', function() {
    const appScreen = document.getElementById('appScreen');
    if (!document.fullscreenElement) {
        appScreen.classList.remove('fullscreen-mode');
    }
});

// Lyrics Functions
function toggleLyrics() {
    const lyricsOverlay = document.getElementById('lyricsOverlay');
    const lyricsBtn = document.getElementById('lyricsBtn');
    
    lyricsOverlay.classList.toggle('show');
    lyricsBtn.classList.toggle('active');
}

function closeLyricsIfClickedOutside(event) {
    if (event.target.id === 'lyricsOverlay') {
        toggleLyrics();
    }
}

async function fetchLyrics(songTitle, artist) {
    const lyricsContent = document.getElementById('lyricsContent');
    
    // Show loading state
    lyricsContent.innerHTML = '<div class="lyrics-loading"><i class="bi bi-hourglass-split"></i><p>Loading lyrics...</p></div>';
    
    try {
        // Clean the song title (remove extra info in brackets, etc.)
        const cleanTitle = cleanSongTitle(songTitle);
        const cleanArtist = cleanArtistName(artist);
        
        console.log('Fetching lyrics for:', cleanArtist, '-', cleanTitle);
        
        // Use Lyrics.ovh API (free, no API key required)
        const url = `https://api.lyrics.ovh/v1/${encodeURIComponent(cleanArtist)}/${encodeURIComponent(cleanTitle)}`;
        
        const response = await fetch(url);
        
        if (!response.ok) {
            throw new Error('Lyrics not found');
        }
        
        const data = await response.json();
        
        if (data.lyrics) {
            displayLyrics(data.lyrics);
        } else {
            showLyricsError('Lyrics not available for this song');
        }
        
    } catch (error) {
        console.error('Error fetching lyrics:', error);
        showLyricsError('Lyrics not found. Try playing another song.');
    }
}

function cleanSongTitle(title) {
    // Remove common patterns from YouTube titles
    let cleaned = title
        .replace(/\(Official.*?\)/gi, '')
        .replace(/\[Official.*?\]/gi, '')
        .replace(/Official Video/gi, '')
        .replace(/Official Audio/gi, '')
        .replace(/Lyric Video/gi, '')
        .replace(/Music Video/gi, '')
        .replace(/\(.*?HD.*?\)/gi, '')
        .replace(/\[.*?HD.*?\]/gi, '')
        .replace(/ft\.|feat\.|featuring/gi, '')
        .replace(/\|.*/g, '')
        .replace(/-.*Official.*/gi, '')
        .trim();
    
    return cleaned;
}

function cleanArtistName(artist) {
    // Remove "VEVO" and other common suffixes from artist names
    let cleaned = artist
        .replace(/VEVO$/gi, '')
        .replace(/Official$/gi, '')
        .replace(/Music$/gi, '')
        .trim();
    
    return cleaned;
}

function displayLyrics(lyrics) {
    const lyricsContent = document.getElementById('lyricsContent');
    lyricsContent.innerHTML = `<pre>${lyrics}</pre>`;
}

function showLyricsError(message) {
    const lyricsContent = document.getElementById('lyricsContent');
    lyricsContent.innerHTML = `
        <div class="lyrics-error">
            <i class="bi bi-exclamation-circle"></i>
            <p>${message}</p>
        </div>
    `;
}

function clearLyrics() {
    const lyricsContent = document.getElementById('lyricsContent');
    lyricsContent.innerHTML = `
        <div class="lyrics-placeholder">
            <i class="bi bi-music-note-list"></i>
            <p>Play a song to see lyrics</p>
        </div>
    `;
}

// Mobile Functions
function toggleMobileSearch() {
    const mobileSearchModal = document.getElementById('mobileSearchModal');
    mobileSearchModal.classList.toggle('show');
}

function toggleMobileSidebar() {
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('show');
}

async function performMobileSearch() {
    const query = document.getElementById('mobileSearchInput').value.trim();
    if (!query) return;
    
    // Switch to YouTube tab to show search results (with safety check)
    if (typeof switchPlatform === 'function') {
        switchPlatform('youtube');
    }
    
    const mobileSongList = document.getElementById('mobileSongList');
    mobileSongList.innerHTML = '<div class="loading"><i class="bi bi-hourglass-split"></i><p>Searching YouTube for: ' + query + '</p></div>';
    
    try {
        const results = await searchYouTube(query);
        displayMobileYouTubeResults(results);
    } catch (error) {
        console.error('Mobile search error:', error);
        mobileSongList.innerHTML = '<div class="error-message"><i class="bi bi-exclamation-triangle"></i><p>Failed to search. ' + error.message + '</p></div>';
    }
}

function displayMobileYouTubeResults(results) {
    youtubeSearchResults = results;
    const mobileSongList = document.getElementById('mobileSongList');
    
    if (results.length === 0) {
        mobileSongList.innerHTML = '<div class="error-message"><p>No results found</p></div>';
        return;
    }
    
    mobileSongList.innerHTML = '';
    
    results.forEach((item, index) => {
        const songItem = document.createElement('div');
        songItem.className = 'song-item';
        songItem.onclick = () => {
            playYouTubeSong(index);
            toggleMobileSearch(); // Close modal after selection
        };
        
        const thumbnail = item.snippet.thumbnails.default.url;
        const title = item.snippet.title;
        const channel = item.snippet.channelTitle;
        
        songItem.innerHTML = `
            <img src="${thumbnail}" alt="${title}">
            <div class="song-item-info">
                <div class="song-item-title">${title}</div>
                <div class="song-item-artist">${channel}</div>
            </div>
        `;
        
        mobileSongList.appendChild(songItem);
    });
}

// Mute Function
function toggleMute() {
    const muteBtn = document.getElementById('muteBtn');
    const volumeSlider = document.getElementById('volumeSlider');
    
    if (isMuted) {
        // Unmute
        isMuted = false;
        volumeSlider.value = previousVolume;
        
        if (currentPlatform === 'youtube' && player && player.setVolume) {
            player.setVolume(previousVolume);
        }
        if (audioPlayer) {
            audioPlayer.volume = previousVolume / 100;
        }
        
        muteBtn.innerHTML = '<i class="bi bi-volume-up-fill"></i>';
        muteBtn.classList.remove('muted');
    } else {
        // Mute
        isMuted = true;
        previousVolume = volumeSlider.value;
        volumeSlider.value = 0;
        
        if (currentPlatform === 'youtube' && player && player.setVolume) {
            player.setVolume(0);
        }
        if (audioPlayer) {
            audioPlayer.volume = 0;
        }
        
        muteBtn.innerHTML = '<i class="bi bi-volume-mute-fill"></i>';
        muteBtn.classList.add('muted');
    }
}

// Share Function
function shareSong() {
    const songTitle = document.getElementById('currentSongTitle').textContent;
    const songArtist = document.getElementById('currentSongArtist').textContent;
    
    if (songTitle === 'No song playing') {
        alert('Please play a song first!');
        return;
    }
    
    const shareText = `🎵 Now playing: ${songTitle} by ${songArtist} on Pixel Play!`;
    const shareUrl = window.location.href;
    
    // Check if Web Share API is available
    if (navigator.share) {
        navigator.share({
            title: 'Pixel Play',
            text: shareText,
            url: shareUrl
        }).then(() => {
            console.log('Shared successfully');
        }).catch((error) => {
            console.log('Error sharing:', error);
            fallbackShare(shareText);
        });
    } else {
        fallbackShare(shareText);
    }
}

function fallbackShare(text) {
    // Copy to clipboard as fallback
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            alert('Song info copied to clipboard! ✓');
        }).catch(() => {
            alert(text);
        });
    } else {
        alert(text);
    }
}

// Disc Animation Function
function triggerDiscAnimation() {
    const vinylDisc = document.querySelector('.vinyl-disc');
    const tonearm = document.querySelector('.tonearm');
    
    // Reset animation by removing classes
    vinylDisc.classList.remove('loaded', 'spinning');
    tonearm.classList.remove('visible');
    
    // Force reflow to restart animation
    void vinylDisc.offsetWidth;
    
    // Add classes to trigger slide-up animation
    setTimeout(() => {
        vinylDisc.classList.add('loaded');
        tonearm.classList.add('visible');
    }, 50);
}

// Service Worker Registration
function registerServiceWorker() {
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('[App] Service Worker registered:', registration.scope);
                
                // Check for updates
                registration.addEventListener('updatefound', () => {
                    console.log('[App] Service Worker update found');
                });
            })
            .catch(error => {
                console.log('[App] Service Worker registration failed:', error);
            });
    }
}

// Media Session API for Background Playback
function initializeMediaSession() {
    if ('mediaSession' in navigator) {
        console.log('[App] Media Session API supported');
        
        // Set action handlers for media controls
        navigator.mediaSession.setActionHandler('play', () => {
            console.log('[Media Session] Play');
            togglePlayPause();
        });
        
        navigator.mediaSession.setActionHandler('pause', () => {
            console.log('[Media Session] Pause');
            togglePlayPause();
        });
        
        navigator.mediaSession.setActionHandler('previoustrack', () => {
            console.log('[Media Session] Previous track');
            playPrevious();
        });
        
        navigator.mediaSession.setActionHandler('nexttrack', () => {
            console.log('[Media Session] Next track');
            playNext();
        });
        
        navigator.mediaSession.setActionHandler('seekbackward', (details) => {
            console.log('[Media Session] Seek backward');
            seekRelative(-10);
        });
        
        navigator.mediaSession.setActionHandler('seekforward', (details) => {
            console.log('[Media Session] Seek forward');
            seekRelative(10);
        });
    } else {
        console.log('[App] Media Session API not supported');
    }
}

// Update Media Session Metadata
function updateMediaSessionMetadata(title, artist, artwork) {
    if ('mediaSession' in navigator) {
        navigator.mediaSession.metadata = new MediaMetadata({
            title: title || 'Unknown Track',
            artist: artist || 'Unknown Artist',
            album: 'Pixel Music',
            artwork: artwork ? [
                { src: artwork, sizes: '96x96', type: 'image/jpeg' },
                { src: artwork, sizes: '128x128', type: 'image/jpeg' },
                { src: artwork, sizes: '192x192', type: 'image/jpeg' },
                { src: artwork, sizes: '256x256', type: 'image/jpeg' },
                { src: artwork, sizes: '384x384', type: 'image/jpeg' },
                { src: artwork, sizes: '512x512', type: 'image/jpeg' }
            ] : []
        });
        
        // Set playback state
        navigator.mediaSession.playbackState = isPlaying ? 'playing' : 'paused';
        
        console.log('[Media Session] Metadata updated:', title, artist);
    }
}

// Seek relative to current position
function seekRelative(seconds) {
    if (currentPlatform === 'youtube' && player && player.getCurrentTime) {
        const currentTime = player.getCurrentTime();
        const newTime = Math.max(0, currentTime + seconds);
        player.seekTo(newTime, true);
    } else if (currentPlatform === 'local' && audioPlayer) {
        const currentTime = audioPlayer.currentTime;
        const newTime = Math.max(0, currentTime + seconds);
        audioPlayer.currentTime = newTime;
    }
}

// ===== RECORDS LIBRARY SYSTEM =====

// Library Manager - localStorage operations
const libraryManager = {
    storageKey: 'pixelMusicLibrary',
    
    // Get all library items
    getAll: function() {
        try {
            const data = localStorage.getItem(this.storageKey);
            return data ? JSON.parse(data) : [];
        } catch (error) {
            console.error('Error reading library:', error);
            return [];
        }
    },
    
    // Save item to library
    save: function(item) {
        try {
            const library = this.getAll();
            
            // Check if already exists
            const exists = library.some(song => song.id === item.id);
            if (exists) {
                return false;
            }
            
            // Add timestamp
            item.dateAdded = new Date().toISOString();
            
            // Add to beginning of array (newest first)
            library.unshift(item);
            
            localStorage.setItem(this.storageKey, JSON.stringify(library));
            return true;
        } catch (error) {
            console.error('Error saving to library:', error);
            return false;
        }
    },
    
    // Remove item from library
    remove: function(id) {
        try {
            let library = this.getAll();
            library = library.filter(song => song.id !== id);
            localStorage.setItem(this.storageKey, JSON.stringify(library));
            return true;
        } catch (error) {
            console.error('Error removing from library:', error);
            return false;
        }
    },
    
    // Check if item is in library
    isInLibrary: function(id) {
        const library = this.getAll();
        return library.some(song => song.id === id);
    },
    
    // Clear entire library
    clearAll: function() {
        try {
            localStorage.removeItem(this.storageKey);
            return true;
        } catch (error) {
            console.error('Error clearing library:', error);
            return false;
        }
    }
};

// Toggle heart icon and add/remove from library
function toggleLibraryHeart(source, id, title, artist, thumbnail, btnElement) {
    const isInLibrary = libraryManager.isInLibrary(id);
    
    if (isInLibrary) {
        // Remove from library
        if (libraryManager.remove(id)) {
            btnElement.classList.remove('active');
            btnElement.querySelector('i').className = 'bi bi-heart';
            showToast('Removed from Records Library');
            
            // Track remove from library
            if (typeof trackRemoveFromLibrary === 'function') {
                trackRemoveFromLibrary(title, artist);
            }
            
            // Refresh library display if on library tab
            const libraryTab = document.querySelector('[data-bs-target="#library"]');
            if (libraryTab && libraryTab.classList.contains('active')) {
                displayLibrarySongs();
            }
        }
    } else {
        // Add to library
        const item = {
            id: id,
            source: source,
            title: title,
            artist: artist,
            thumbnail: thumbnail
        };
        
        if (libraryManager.save(item)) {
            btnElement.classList.add('active');
            btnElement.querySelector('i').className = 'bi bi-heart-fill';
            showToast('Added to Records Library');
            
            // Track add to library
            if (typeof trackAddToLibrary === 'function') {
                trackAddToLibrary(title, artist);
            }
        }
    }
    
    updateLibraryCount();
}

// Display library songs
function displayLibrarySongs() {
    const librarySongList = document.getElementById('librarySongList');
    const emptyLibrary = document.getElementById('emptyLibrary');
    const clearLibraryBtn = document.getElementById('clearLibraryBtn');
    const library = libraryManager.getAll();
    
    if (library.length === 0) {
        // Show empty state
        emptyLibrary.style.display = 'block';
        if (clearLibraryBtn) clearLibraryBtn.style.display = 'none';
        
        // Remove any song items
        const existingSongs = librarySongList.querySelectorAll('.song-item');
        existingSongs.forEach(song => song.remove());
        return;
    }
    
    // Hide empty state
    emptyLibrary.style.display = 'none';
    if (clearLibraryBtn) clearLibraryBtn.style.display = 'inline-block';
    
    // Remove existing songs before adding new ones
    const existingSongs = librarySongList.querySelectorAll('.song-item');
    existingSongs.forEach(song => song.remove());
    
    library.forEach((item) => {
        const songItem = document.createElement('div');
        songItem.className = 'song-item';
        
        // Build onclick based on source
        let onclick = '';
        if (item.source === 'youtube') {
            onclick = `playLibrarySong('${item.id}', '${item.title.replace(/'/g, "\\'")}', '${item.artist.replace(/'/g, "\\'")}', '${item.thumbnail}')`;
        } else if (item.source === 'local') {
            onclick = `playLibraryLocalSong('${item.id}', '${item.title.replace(/'/g, "\\'").replace(/"/g, '\\"')}')`;
        }
        
        // Build thumbnail/icon
        const imgHtml = item.thumbnail 
            ? `<img src="${item.thumbnail}" alt="${item.title}">`
            : `<i class="bi bi-file-music" style="font-size: 2rem; color: var(--text-dim);"></i>`;
        
        songItem.innerHTML = `
            ${imgHtml}
            <div class="song-item-info" onclick="${onclick}" style="cursor: pointer;">
                <div class="song-item-title">${item.title}</div>
                <div class="song-item-artist">${item.artist}</div>
            </div>
            <button class="song-heart-btn active" onclick="event.stopPropagation(); removeFromLibrary('${item.id}', this);" title="Remove from Records Library">
                <i class="bi bi-heart-fill"></i>
            </button>
        `;
        
        librarySongList.appendChild(songItem);
    });
}

// Remove from library (used in library view)
function removeFromLibrary(id, btnElement) {
    if (libraryManager.remove(id)) {
        showToast('Removed from Records Library');
        displayLibrarySongs();
        updateLibraryCount();
        syncHeartStates();
    }
}

// Play song from library (YouTube)
function playLibrarySong(videoId, title, artist, thumbnail) {
    currentPlatform = 'youtube';
    
    // Stop local audio if playing
    audioPlayer.pause();
    
    // Load and play YouTube video
    if (player && player.loadVideoById) {
        player.loadVideoById(videoId);
        player.playVideo();
        isPlaying = true;
    }
    
    // Update UI
    updateSongInfo(title, artist, thumbnail);
    updatePlayPauseButton();
    updateMediaSessionMetadata(title, artist, thumbnail);
    
    // Trigger disc slide-up animation
    triggerDiscAnimation();
    
    // Fetch and display lyrics
    fetchLyrics(title, artist);
    
    // Highlight active song
    document.querySelectorAll('.song-item').forEach(item => {
        item.classList.remove('active');
    });
    event.target.closest('.song-item')?.classList.add('active');
}

// Play local song from library
function playLibraryLocalSong(fileUrl, title) {
    // Find the file in localFiles array
    const fileIndex = localFiles.findIndex(f => f.url === fileUrl);
    if (fileIndex !== -1) {
        playLocalFile(fileIndex);
    } else {
        showToast('Local file no longer available', 'error');
    }
}

// Clear entire library
function clearLibrary() {
    if (confirm('Are you sure you want to clear your entire Records Library? This cannot be undone.')) {
        if (libraryManager.clearAll()) {
            displayLibrarySongs();
            updateLibraryCount();
            syncHeartStates();
            showToast('Records Library cleared');
        }
    }
}

// Update library count badge
function updateLibraryCount() {
    const library = libraryManager.getAll();
    const countBadge = document.getElementById('libraryCount');
    
    if (countBadge) {
        countBadge.textContent = library.length;
        countBadge.style.display = library.length > 0 ? 'inline-block' : 'none';
    }
}

// Sync heart states across all displayed songs
function syncHeartStates() {
    const allHeartButtons = document.querySelectorAll('.song-heart-btn');
    
    allHeartButtons.forEach(btn => {
        const onclick = btn.getAttribute('onclick');
        if (!onclick) return;
        
        // Extract ID from onclick attribute
        const match = onclick.match(/toggleLibraryHeart\([^,]+,\s*'([^']+)'/);
        if (match && match[1]) {
            const songId = match[1];
            const isInLibrary = libraryManager.isInLibrary(songId);
            
            if (isInLibrary) {
                btn.classList.add('active');
                btn.querySelector('i').className = 'bi bi-heart-fill';
            } else {
                btn.classList.remove('active');
                btn.querySelector('i').className = 'bi bi-heart';
            }
        }
    });
}

// Show toast notification
function showToast(message, type = 'success') {
    // Check if toast container exists, create if not
    let toastContainer = document.getElementById('toastContainer');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toastContainer';
        toastContainer.style.cssText = 'position: fixed; bottom: 2rem; right: 2rem; z-index: 9999;';
        document.body.appendChild(toastContainer);
    }
    
    const toast = document.createElement('div');
    toast.className = `toast-notification toast-${type}`;
    toast.style.cssText = `
        background: ${type === 'success' ? 'rgba(60, 80, 60, 0.95)' : 'rgba(80, 60, 60, 0.95)'};
        border: 1px solid ${type === 'success' ? 'rgba(100, 150, 100, 0.5)' : 'rgba(150, 100, 100, 0.5)'};
        color: var(--text-light);
        padding: 1rem 1.5rem;
        border-radius: 5px;
        margin-top: 0.5rem;
        animation: slideIn 0.3s ease;
    `;
    toast.textContent = message;
    
    toastContainer.appendChild(toast);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            toast.remove();
        }, 300);
    }, 3000);
}

// Initialize library on page load
document.addEventListener('DOMContentLoaded', function() {
    updateLibraryCount();
});
